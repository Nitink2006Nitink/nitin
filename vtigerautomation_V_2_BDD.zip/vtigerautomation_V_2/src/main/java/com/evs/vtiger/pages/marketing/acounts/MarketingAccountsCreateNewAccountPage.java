package com.evs.vtiger.pages.marketing.acounts;

import java.util.List;
import java.util.Map;

import com.evs.vtiger.utils.WebUtil;

import net.bytebuddy.utility.RandomString;

public class MarketingAccountsCreateNewAccountPage extends MarketingAccountCreateNewAccountOR {

	
	private WebUtil wt;
	
	public MarketingAccountsCreateNewAccountPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}
	
//	public void enterMarketingAccountInfo(Map<String, String> accountMapData) {
//
//		RandomString rnd=new RandomString(7);
//		String randomString=rnd.nextString();
//		
//		wt.mySendKeys(accountMapData.get("AccountName")+randomString, getAccountNameTB());
//		wt.mySendKeys(accountMapData.get("WebSite"),getWebsiteNameTB());
//		wt.mySendKeys(accountMapData.get("Phone"),getPhoneNumberTB());
//		wt.mySendKeys(accountMapData.get("Email"),getEmailTB());
//
//		wt.mySendKeys(accountMapData.get("City"),getBillingCityTB());
//		wt.mySendKeys(accountMapData.get("State"),getBillingStataTB());
//		wt.mySendKeys(accountMapData.get("PinCode"),getBillingPostalCodeTB());
//		
//	}
	
	public void enterMarketingAccountInfo(String accountName, String email, String city, String website, String state, String pincode, String phone) {
		 RandomString rnd = new RandomString(5);
		String randomString = rnd.nextString();
		wt.mySendKeys(accountName+randomString, getAccountNameTB());
		wt.mySendKeys(website,getWebsiteNameTB());
		wt.mySendKeys(phone,getPhoneNumberTB());
		wt.mySendKeys(email,getEmailTB());

		wt.mySendKeys(city,getBillingCityTB());
		wt.mySendKeys(state,getBillingStataTB());
		wt.mySendKeys(pincode,getBillingPostalCodeTB());
		
	}

	public void clickSaveButton() {
		wt.click(getSaveMarketingAccountBT());
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clickCancelButton() {
		wt.click(getCancelMarketingAccountBT());

	}

	public String verifyAlertMassage(String alertMassage) {
		String massage = wt.alertHandleGetText();
		wt.alertHandleByAccept();
		wt.verifyText(massage, alertMassage);
		return massage;
	}
	
}
