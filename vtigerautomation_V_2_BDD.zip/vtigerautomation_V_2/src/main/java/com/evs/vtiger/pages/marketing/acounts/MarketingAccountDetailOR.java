package com.evs.vtiger.pages.marketing.acounts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingAccountDetailOR {

	public MarketingAccountDetailOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}

	@FindBy(xpath = "//input[@value='Edit']")
	private WebElement marketingLink;
	
}
