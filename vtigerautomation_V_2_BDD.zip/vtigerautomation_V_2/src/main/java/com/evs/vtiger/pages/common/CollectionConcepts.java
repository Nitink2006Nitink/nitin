package com.evs.vtiger.pages.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionConcepts {

	public static void main(String[] args) {
		m1();
	}
	
	public static void main() {
        new ArrayList<Integer>();
		Object[] names= {"rahul", "yadav", "it",221406, "bhadohi"};
		
		
		///  Map Interface -  HashMap , TreeMap , LinkedHashMap
		Map<String, String> mapObj=new HashMap<String, String>();
		mapObj.put("firstName", "rahul");
		mapObj.put("city", "bhadohi");
		mapObj.put("prof", "it");
		mapObj.put("lastName", "yadav");
		mapObj.put("prof", "teaching");
		
		mapObj.get("prof");
		
		
		new ArrayList<String>();
		
		
		
		/// Array
		///  List  -  ArrayList  -  LinkedList
		//  Set  -  HashSet, TreeSet , LinkedHashSet
		///  Iterator - 
		Set<String> setObj=new HashSet<String>();
		    setObj.add("rahul");
		    setObj.add("ram");
		    setObj.add("raj");
		for(String name : setObj) {
			System.out.println(name);
		}
		
		for(String name : setObj) {
			System.out.println(name);
		}
		
		System.out.println("=================");
	  Iterator<String>	itObj=setObj.iterator();
	  while(itObj.hasNext()==true) {
		  String data=itObj.next();
		  System.out.println(data);
		  
	  }
	
	  while(itObj.hasNext()==true) {
		  String data=itObj.next();
		  System.out.println(data);
		  
	  }
		
		
	}

	public static void m1() {
		Map<String, String> mapobj = new HashMap<String, String>();
		mapobj.put("FirstName", "Arjun");
		mapobj.put("LastName", "Yadav");
		mapobj.put("Address", "Jaunpur");
		mapobj.put("Prof", "None");
	
		
		
		
	}
}
