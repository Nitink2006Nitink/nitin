package com.evs.vtiger.pages.marketing.acounts;

import com.evs.vtiger.utils.WebUtil;

public class MarketingAccountsDetailPage extends MarketingAccountDetailOR{

	private WebUtil wt;
	
	public MarketingAccountsDetailPage(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void clickEditButton() {
		wt.click(getMarketingLink());
	}
	
	
}
