package com.evs.vtiger.pages.marketing.documents;

public class MarketingDocumentsCreateNewDocumentsPage extends MarketingDocumentsCreateNewDocumentsOR{

	
	
	
	
	
	
	
	
}
