package com.evs.vtiger.pages.marketing.contacts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingContactSelectAccountNameWindowOR {

	public MarketingContactSelectAccountNameWindowOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}
	
	@FindBy(xpath = "//input[@id='search_txt']")
	private WebElement searchTB;
	
	@FindBy(xpath = "//input[@name='search']")
	private WebElement searchNowTB;
	
	@FindBy(xpath = "//a[text()='samplevtiger']")
	private WebElement selectAccountNameValue;
}
