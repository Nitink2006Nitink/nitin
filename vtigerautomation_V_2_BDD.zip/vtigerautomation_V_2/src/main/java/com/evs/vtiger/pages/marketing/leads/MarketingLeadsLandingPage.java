package com.evs.vtiger.pages.marketing.leads;

import com.evs.vtiger.utils.WebUtil;

public class MarketingLeadsLandingPage extends MarketingLeadsLandingOR{

	private WebUtil wt;
	
	public MarketingLeadsLandingPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}

	public void clickCreateMarketingLeadsButton() {
		wt.click(getCreateLeadsBT());
	}
}
