package com.evs.vtiger.pages.inventory.invoice;

import com.evs.vtiger.utils.WebUtil;

public class InventoryInvoiceLandingPage extends InventoryInvoiceLandingOR{
	
	private WebUtil wt;
	
	public InventoryInvoiceLandingPage(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void clickCreateInventoryInvoiceButton() {
		
		wt.click(getInvoiceCreationBT());
	}
}
