package com.evs.vtiger.pages.inventory.invoice;

import com.evs.vtiger.utils.WebUtil;

public class InventoryInvoiceSelectProductWindow extends InventoryInvoiceSelectProductWindowOR{
	
	private WebUtil wt;
	
	public InventoryInvoiceSelectProductWindow(WebUtil wu) {
		super(wu);
		this.wt=wu;
}

	public void switchInventoryInvoiceWindowToProductSearchByURL(String url) {
		wt.mySwitchToWindowByUrl(url);
	}
	
	public void searchAndSelectProduct() {
		wt.click(getProductBT());
		wt.click(getSelectProductBT());
		
	
	}
}
