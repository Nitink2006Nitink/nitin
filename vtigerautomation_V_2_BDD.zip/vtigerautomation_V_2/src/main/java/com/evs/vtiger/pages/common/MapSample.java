package com.evs.vtiger.pages.common;

import java.util.HashMap;
import java.util.Set;

public class MapSample {

	public static void main(String[] args) {
HashMap hm= new HashMap();
hm.put(1, "A");
hm.put(2, "v");
hm.put(3, "e");
hm.put(4, "w");
hm.put(5, "A");
		System.out.println(hm);
Set shm=hm.entrySet();
shm.iterator();
	}

}
