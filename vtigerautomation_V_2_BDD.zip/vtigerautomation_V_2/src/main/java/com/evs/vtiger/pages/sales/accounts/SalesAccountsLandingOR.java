package com.evs.vtiger.pages.sales.accounts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class SalesAccountsLandingOR {
	
	public SalesAccountsLandingOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}

	@FindBy(xpath = "//img[@alt='Create Account...']")
	private WebElement createAccountBT;
}
