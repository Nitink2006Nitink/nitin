package com.evs.vtiger.pages.inventory.invoice;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class InventoryInvoiceCreateNewInvoiceOR {

	public InventoryInvoiceCreateNewInvoiceOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}

	@FindBy(xpath = "//input[@name='subject']")
	private WebElement subjectTB;
	
	@FindBy(xpath = "//input[@id='customerno']")
	private WebElement customerNoTB;
	
	@FindBy(xpath = "(//img[@title='Select'])[2]")
	private WebElement contactNameSelectBT;
	
	@FindBy(xpath = "(//img[@title='Select'])[3]")
	private WebElement accountNameSelectBT;
	
	@FindBy(xpath = "//textarea[@name='bill_street']")
	private WebElement billingAddressTB;
	
	@FindBy(xpath = "//input[@id='bill_city']")
	private WebElement billingCityTB;
	
	@FindBy(xpath = "//input[@id='bill_state']")
	private WebElement billingStateTB;
	
	@FindBy(xpath = "//input[@id='bill_code']")
	private WebElement billingPostalCodeTB;
	
	@FindBy(xpath = "//input[@id='bill_country']")
	private WebElement billingCountryTB;
	
	@FindBy(xpath = "//b[text()='Copy Billing address']")
	private WebElement copyBillingAddressBT;
	
	@FindBy(xpath = "//img[@id='searchIcon1']")
	private WebElement searchProductIcon;
	
	@FindBy(xpath = "//textarea[@id='comment1']")
	private WebElement commentTB;
	
	@FindBy(xpath = "//input[@id='qty1']")
	private WebElement quentityTB;
	
	@FindBy(xpath = "(//input[@title='Save [Alt+S]'])[2]")
	private WebElement saveInvoiceBT;
	
	@FindBy(xpath = "(//input[@title='Cancel [Alt+X]'])[2]")
	private WebElement cancelInvoiceBT;
}
