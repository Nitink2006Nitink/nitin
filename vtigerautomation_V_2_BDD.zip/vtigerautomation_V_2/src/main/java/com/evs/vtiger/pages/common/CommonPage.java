
package com.evs.vtiger.pages.common;

import com.evs.vtiger.utils.WebUtil;



public class CommonPage extends CommonReusableOR{
	
	private WebUtil wt;  ///  null
	
	public CommonPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
		
	}
	
	
	/// credential 
	////  it will use generic methods to automate application dependent generic methods
	
	//    private WebElement userNameTB="//input[@name='user_name']";
	
	////   1) make constructor in each page class and initialize WebElement there
	////   2 
	
	////  Object Repository  -  WebElement 
	
	
	////   approach    -  Shared OR CommonOR 
	
	
	    
    ///////////////////////////////

	public  void validLogin(String uname, String pwd) {
		wt.mySendKeys(uname, getUserNameTB());
		wt.mySendKeys(pwd, getPasswordTB());
		wt.click(getLoginBT());

	}
	public  void invalidLogin(String uname, String pwd) {
		wt.mySendKeys(uname, getUserNameTB());
		wt.mySendKeys(pwd, getPasswordTB());
		wt.click(getLoginBT());

	}


	public void logout() {
		wt.click(getLogoutLK());
	}

	
	public void close() {
		wt.close();
	}
	
	public void gotoMarketingAccountsPage() {
		wt.mouseOver(getMarketingLK());
		wt.mouseClick(getMarketingAccountLK());

	}


	public void gotoMarketingLeadsPage() {
				wt.mouseOver(getMarketingLK());
				wt.mouseClick(getMarketingLeadsLK());

	}

	public void gotoInventoryInvoicePage() {
		wt.mouseOver(getInventoryLK());
		wt.mouseClick(getInventoryInvoiceLK());

	}

	public void gotoMarketingContactsPage() {
		wt.mouseOver(getMarketingLK());
		wt.mouseClick(getMarketingContactLK());

	}
	
	public void gotoSalesLeadsPage() {
		wt.mouseOver(getSalesLK());
		wt.mouseClick(getSalesLeadsLK());
	}
	
	public void gotoSalesAccountPage() {
		wt.mouseOver(getSalesLK());
		wt.mouseClick(getSalesAccountLK());
	}
}
