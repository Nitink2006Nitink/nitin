package com.evs.vtiger.pages.sales.accounts;

import com.evs.vtiger.utils.WebUtil;

public class SalesAccountsCreateNewAccountPage extends SalesAccountsCreateNewAccountOR{

	private WebUtil wt;
	
	public SalesAccountsCreateNewAccountPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}

	public void enterSalesAccountInfo() {

		wt.mySendKeys("xyzabcd", getAccountNameTB());
		wt.mySendKeys("VtigerTesting.com",getWebsiteNameTB());
		wt.mySendKeys("(765) 876 225",getPhoneNumberTB());
		wt.mySendKeys("arjun_yadav543@1secmail.com",getEmailTB());

		wt.selectByValue(getAssignToDropdown(), "1");

		wt.mySendKeys("State-UP-City-Jaunpur",getBillingAddressTB());
		wt.mySendKeys("None",getBill_poboxTB());
		wt.mySendKeys("Varanasi",getBillingCityTB());
		wt.mySendKeys("UP",getBillingStataTB());
		wt.mySendKeys("423245",getBillingPostalCodeTB());
		wt.mySendKeys("India",getBillingCountryTB());
		wt.click(getAccountInfoCopySB());
		wt.mySendKeys("This Account Creation is only for testing Purpose",getDescriptionTB());

	}

	public void clickSaveButton() {
		wt.click(getSaveMarketingAccountBT());

	}

	public void clickCancelButton() {
		wt.click(getCancelMarketingAccountBT());

	}

}
