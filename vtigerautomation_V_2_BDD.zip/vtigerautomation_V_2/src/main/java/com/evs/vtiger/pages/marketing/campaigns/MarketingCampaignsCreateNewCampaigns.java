package com.evs.vtiger.pages.marketing.campaigns;

public class MarketingCampaignsCreateNewCampaigns {

}
