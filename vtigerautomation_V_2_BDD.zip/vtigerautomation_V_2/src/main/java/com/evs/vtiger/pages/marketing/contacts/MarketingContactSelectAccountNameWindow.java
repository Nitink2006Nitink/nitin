package com.evs.vtiger.pages.marketing.contacts;


import com.evs.vtiger.utils.WebUtil;

public class MarketingContactSelectAccountNameWindow extends MarketingContactSelectAccountNameWindowOR {

	private WebUtil wt;
	
	public MarketingContactSelectAccountNameWindow(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void switchByURLFromMarketingContactWindowToAccountName(String url) {
		wt.mySwitchToWindowByUrl(url);
	}
	
	public void searchAndSelectAccountName(String searchValue) {
		wt.mySendKeys(searchValue ,getSearchTB());
		wt.click(getSearchNowTB());
		wt.click(getSelectAccountNameValue());
		
	}
	
}
