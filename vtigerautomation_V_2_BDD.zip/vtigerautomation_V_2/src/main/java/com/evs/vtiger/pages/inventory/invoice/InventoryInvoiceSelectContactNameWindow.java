package com.evs.vtiger.pages.inventory.invoice;

import com.evs.vtiger.utils.WebUtil;

public class InventoryInvoiceSelectContactNameWindow extends InventoryInvoiceSelectContactNameWindowOR{
 
	private WebUtil wt;
	
	public InventoryInvoiceSelectContactNameWindow(WebUtil wu) {
		super(wu);
		this.wt=wu;
}

	public void switchByURLFromInventoryInvoiceWindowToContactName(String url) {
		wt.mySwitchToWindowByUrl(url);
	}
	
	public void searchAndSelectContactName(String searchValue) {
		wt.mySendKeys(searchValue ,getSearchTB());
		wt.click(getSearchNowBT());
		wt.click(getSelectContactNameValue());
		wt.alertHandleByAccept();
	
	}
	
}
