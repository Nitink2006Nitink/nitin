package com.evs.vtiger.pages.marketing.contacts;

import com.evs.vtiger.utils.WebUtil;

public class MarketingContactsLandingPage extends MarketingContactLandingOR {

	private WebUtil wt;
	
	public MarketingContactsLandingPage(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void clickCreateMarketingContactsButton() {
		wt.click(getContactCreationBT());
	}
}
