package com.evs.vtiger.pages.sales.leads;


import java.util.List;

import com.evs.vtiger.utils.WebUtil;

import net.bytebuddy.utility.RandomString;

public class SalesLeadsCreateNewLeadPage extends SalesLeadsCreateNewLeadOR{
	
	private WebUtil wt;
	
	public SalesLeadsCreateNewLeadPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}

	public void enterSalesLeadsInfo(List<String> dataList) {
		
		String ranStr = new RandomString().nextString();
		String ranStr2 = new RandomString().nextString();

		wt.mySendKeys(dataList.get(0)+ranStr , getFirstNameTB());
		wt.mySendKeys(dataList.get(1)+ranStr2, getLastNameTB());
		wt.mySendKeys(dataList.get(2), getCompanyNameTB());
		
//		wt.mySendKeys("Testing Purpose", getTitleTB());
//		wt.selectByValue(getLeadSourceDropsown(), "Self Generated");
		
		wt.selectByValue(getLeadStatusDropdown(), dataList.get(3));
		wt.mySendKeys(dataList.get(4), getMobileNumberTB());
		wt.mySendKeys(dataList.get(5), getEmailIdTB());
		wt.mySendKeys(dataList.get(6), getStreetTB());
		
//		wt.mySendKeys("643575", getPoboxTB());
//		wt.mySendKeys("643572", getPostalCodeTB());
		
		wt.mySendKeys(dataList.get(7), getCityTB());
		wt.mySendKeys(dataList.get(8), getCountryTB());
		wt.mySendKeys(dataList.get(9), getStateTB());
		wt.mySendKeys(dataList.get(10), getDescriptionTB());
	
	}
	
public void enterSalesLeadsInfo(String firstName, String lastName, String Company, String leadStatus, String phone, String email, String address, String city, String country, String state, String description ) {
		
		String ranStr = new RandomString().nextString();
		String ranStr2 = new RandomString().nextString();
		String ranStr3 = new RandomString(3).nextString();

		wt.mySendKeys(firstName+ranStr , getFirstNameTB());
		wt.mySendKeys(lastName+ranStr2, getLastNameTB());
		wt.mySendKeys(Company , getCompanyNameTB());
		
//		wt.mySendKeys("Testing Purpose", getTitleTB());
//		wt.selectByValue(getLeadSourceDropsown(), "Self Generated");
		
		wt.selectByValue(getLeadStatusDropdown(), leadStatus);
		wt.mySendKeys(phone, getMobileNumberTB());
		wt.mySendKeys(email+ranStr3, getEmailIdTB());
		wt.mySendKeys(address, getStreetTB());
		
//		wt.mySendKeys("643575", getPoboxTB());
//		wt.mySendKeys("643572", getPostalCodeTB());
		
		wt.mySendKeys(city, getCityTB());
		wt.mySendKeys(country , getCountryTB());
		wt.mySendKeys(state, getStateTB());
		wt.mySendKeys(description, getDescriptionTB());
	
	}
	
	public void clickOnSaveButton() {
		wt.click(getSaveLeadBT());
	}
	
	public void clickOnCancelButton() {
		wt.click(getCancelLeadBT());
		
	}
	
	
	
	
}
