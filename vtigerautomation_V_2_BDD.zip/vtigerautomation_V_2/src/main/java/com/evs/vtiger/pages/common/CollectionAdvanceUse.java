package com.evs.vtiger.pages.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CollectionAdvanceUse {

	public static List<String> getInfo() {
		String a="abcd";
		String b="xyz";
		List<String> listStr=new ArrayList<String>();
		listStr.add(a);
		listStr.add(b);
		return listStr;
	}
	
	
	public static void main(String[] args) {
	///  Map - Interface
////  HashMap  , TreeMap, LinkedHashMap
		List<String> arrStr=getInfo();
		String p=arrStr.get(0);
		String q=arrStr.get(1);
	  List<Map<String, String>> listMapObj= createAndGetAllPersonInfoinListMap();
	  Map<String, String> secondMap=listMapObj.get(1);
	  String cityName=secondMap.get("city");
	  System.out.println(cityName);
	  
	  List<List<String>> listList=createAndGetAllPersonInfoinListList();
	  List<String> dataList=listList.get(2);
	  String cityFromList=dataList.get(1);
	  
		
	}
	
public static List<List<String>> createAndGetAllPersonInfoinListList() {
		List<String> list1= new ArrayList<String>();
		list1.add("Bhadohi");
		list1.add("Mondh");
		list1.add("Rahul");
		List<String> list2= new ArrayList<String>();
		list2.add("Jaunpur");
		list2.add("Rampur");
		list2.add("Rakesh");
		List<String> list3= new ArrayList<String>();
		list3.add("Bhadohi");
		list3.add("Aurai");
		list3.add("Sandeep");
		
		List<List<String>> twoDimList=new ArrayList<List<String>>();
		twoDimList.add(list1);
		twoDimList.add(list2);
		twoDimList.add(list3);
		
		return twoDimList;
		
		
	}
	
	
	
	public static List<Map<String,String>> createAndGetAllPersonInfoinListMap() {
		
		Map<String, String> map1= new HashMap<String, String>();
		map1.put("city", "bhadohi");
		map1.put("town", "mondh");
		map1.put("name", "rahul");

		Map<String, String> map2=new HashMap<String, String>();
		map2.put("city", "jaunpur");
		map2.put("town", "rampur");
		map2.put("name", "rakesh");
		
		Map<String, String> map3=new HashMap<String, String>();
		map3.put("city", "bhadohi");
		map3.put("town", "aurai");
		map3.put("name", "sachin");
		List<Map<String,String>> listMapString=new ArrayList<Map<String,String>>();
		listMapString.add(map1);
		listMapString.add(map2);
		listMapString.add(map3);
	
		return listMapString;
		
		
	}
	
	
	

}
