package com.evs.vtiger.pages.inventory.invoice;

import com.evs.vtiger.utils.WebUtil;

public class InventoryInvoiceSelectAccountNameWindow extends InventoryInvoiceSelectAccountNameWindowOR{

	private WebUtil wt;
	
	public InventoryInvoiceSelectAccountNameWindow(WebUtil wu) {
		super(wu);
		this.wt=wu;	
		}

	public void switchInventoryInvoiceWindowToAccountNameSelectByURL(String url) {
		wt.mySwitchToWindowByUrl(url);
	}
	
	public void searchAndSelectAccountName(String searchValue) {
		wt.mySendKeys(searchValue ,getSearchTB());
		wt.click(getSearchNowBT());
		wt.click(getSelectAccountNameValue());
		wt.alertHandleByAccept();
	
	}
}
