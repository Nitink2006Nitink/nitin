package com.evs.vtiger.pages.inventory.invoice;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class InventoryInvoiceLandingOR {

	public InventoryInvoiceLandingOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}
	
	@FindBy(xpath = "//img[@title='Create Invoice...']")
	private WebElement invoiceCreationBT;
}
