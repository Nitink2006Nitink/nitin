package com.evs.vtiger.pages.common;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CommonReusableOR {
	public CommonReusableOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this); /////  

	}
	
	
	 private String xyz="abcd";
	 
	 
	 private WebElement  abc;
	 
	@FindBy(xpath = "//input[@name='user_name']")
	@CacheLookup
    private WebElement userNameTB;    ///  null 
	
	
	@FindBy(xpath = "//input[@name='user_password']" )
	private WebElement passwordTB;
	
	@FindBy(xpath ="//input[@name='Login']")
	private WebElement loginBT;
	
	@FindBy(xpath ="//a[text()='Sign Out']")
	private WebElement logoutLK;
	
	@FindBy(xpath ="//a[text()='Marketing']")
	private WebElement marketingLK;
	
	@FindBy(xpath ="//a[text()='Inventory']")
	private WebElement inventoryLK;
	
	@FindBy(xpath ="//div[@id='Marketing_sub']//a[text()='Accounts']")
	private WebElement marketingAccountLK;
    
	@FindBy(xpath ="//div[@id='Marketing_sub']//a[text()='Contacts']")
	private WebElement marketingContactLK;
    
	@FindBy(xpath ="//div[@id='Marketing_sub']//a[text()='Leads']")
	private WebElement marketingLeadsLK;
    
	@FindBy(xpath ="//div[@id='Inventory_sub']//a[text()='Invoice']")
	private WebElement inventoryInvoiceLK;
	
	@FindBy(xpath = "//a[text()='Sales']")
    private WebElement salesLK;
	
	@FindBy(xpath = "//div[@id='Sales_sub']//a[text()='Leads']")
	private WebElement salesLeadsLK;
	
	@FindBy(xpath = "//div[@id='Sales_sub']//a[text()='Accounts']")
	private WebElement salesAccountLK;
	
	
	
	String usena="";

	@FindBys(@FindBy(xpath="//input[@name='selected_id']"))
	private List<WebElement>  checkboxList;
	
	
	
	
}
