package com.evs.vtiger.pages.marketing.acounts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingAccountCreateNewAccountOR {

	public MarketingAccountCreateNewAccountOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}
	
	@FindBy(xpath = "//input[@name='accountname']")
	private WebElement accountNameTB;
	
	@FindBy(xpath = "//input[@name='website']")
	private WebElement websiteNameTB;
	
	@FindBy(xpath = "//input[@id='phone']")
	private WebElement phoneNumberTB;
	
	@FindBy(xpath = "//input[@id='email1']")
	private WebElement emailTB;
	
	@FindBy(xpath = "//select[@name='assigned_user_id']")
	private WebElement assignToDropdown;
	
	@FindBy(xpath = "//textarea[@name='bill_street']")
	private WebElement billingAddressTB;
	
	@FindBy(xpath = "//input[@id='bill_pobox']")
	private WebElement bill_poboxTB;
	
	@FindBy(xpath = "//input[@id='bill_city']")
	private WebElement billingCityTB;
	
	@FindBy(xpath = "//input[@id='bill_state']")
	private WebElement billingStataTB;
	
	@FindBy(xpath = "//input[@id='bill_code']")
	private WebElement billingPostalCodeTB;
	
	@FindBy(xpath = "//input[@id='bill_country']")
	private WebElement billingCountryTB;
	
	@FindBy(xpath = "//b[text()='Copy Billing address']/preceding-sibling::input")
	private WebElement accountInfoCopySB;
	
	@FindBy(xpath = "//textarea[@name='description']")
	private WebElement descriptionTB;
	
	@FindBy(xpath = "(//input[@title='Save [Alt+S]'])[2]")
	private WebElement saveMarketingAccountBT;
	
	@FindBy(xpath = "(//input[@title='Cancel [Alt+X]'])[2]")
	private WebElement cancelMarketingAccountBT;

}
