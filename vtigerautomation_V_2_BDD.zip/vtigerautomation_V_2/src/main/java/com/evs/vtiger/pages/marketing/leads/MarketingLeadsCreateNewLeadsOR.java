package com.evs.vtiger.pages.marketing.leads;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingLeadsCreateNewLeadsOR {

	public MarketingLeadsCreateNewLeadsOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}
	
	@FindBy(xpath = "//input[@name='firstname']")
	private WebElement firstNameTB;
	
	@FindBy(xpath = "//input[@name='lastname']")
	private WebElement lastNameTB;
	
	@FindBy(xpath = "//input[@name='company']")
	private WebElement companyNameTB;
	
	@FindBy(xpath = "//input[@id='designation']")
	private WebElement titleTB;
	
	@FindBy(xpath = "//select[@name='leadsource']")
	private WebElement leadSourceDropsown;
	
	@FindBy(xpath = "//select[@name='leadstatus']")
	private WebElement leadStatusDropdown;
	
	@FindBy(xpath = "//input[@id='mobile']")
	private WebElement mobileNumberTB;
	
	@FindBy(xpath = "//input[@id='email']")
	private WebElement emailIdTB;
	
	@FindBy(xpath = "//textarea[@name='lane']")
	private WebElement streetTB;
	
	
	@FindBy(xpath = "//input[@id='pobox']")
	private WebElement poboxTB;
	
	@FindBy(xpath = "//input[@id='code']")
	private WebElement postalCodeTB;
	
	@FindBy(xpath = "//input[@id='city']")
	private WebElement cityTB;
	
	@FindBy(xpath = "//input[@id='country']")
	private WebElement countryTB;
	
	@FindBy(xpath = "//input[@id='state']")
	private WebElement stateTB;
	
	@FindBy(xpath = "//textarea[@name='description']")
	private WebElement descriptionTB;
	
	@FindBy(xpath = "(//input[@title='Save [Alt+S]'])[2]")
	private WebElement saveLeadBT;
	
	@FindBy(xpath = "(//input[@title='Cancel [Alt+X]'])[2]")
	private WebElement cancelLeadBT;
	
}
