package com.evs.vtiger.pages.marketing.leads;

import com.evs.vtiger.utils.WebUtil;

public class MarketingLeadsCreateNewLeadsPage extends MarketingLeadsCreateNewLeadsOR{

	private WebUtil wt;
	
	public MarketingLeadsCreateNewLeadsPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}

	public void enterMarketingLeadsInfo() {
		wt.mySendKeys("Arjun", getFirstNameTB());
		wt.mySendKeys("Yadav", getLastNameTB());
		wt.mySendKeys("vtigercrm.com", getCompanyNameTB());
		wt.mySendKeys("Testing Purpose", getTitleTB());
		wt.selectByValue(getLeadSourceDropsown(), "Self Generated");
		wt.selectByValue(getLeadStatusDropdown(), "Attempted to Contact");
		wt.mySendKeys("8756454327", getMobileNumberTB());
		wt.mySendKeys("yadav12arjun@1secmail.com", getEmailIdTB());
		wt.mySendKeys("123 Anywere", getStreetTB());
		wt.mySendKeys("643575", getPoboxTB());
		wt.mySendKeys("643572", getPostalCodeTB());
		wt.mySendKeys("Jaunpur", getCityTB());
		wt.mySendKeys("India", getCountryTB());
		wt.mySendKeys("Utter Predesh", getStateTB());
		wt.mySendKeys("This Lead Account Creation Only For Testing Purpose...", getDescriptionTB());
	
	}
	
	public void clickOnSaveButton() {
		wt.click(getSaveLeadBT());
	}
	
	public void clickOnCancelButton() {
		wt.click(getCancelLeadBT());
		
	}
}
