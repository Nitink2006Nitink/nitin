package com.evs.vtiger.pages.marketing.acounts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingAccountLandingOR {

	public MarketingAccountLandingOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);

	}
    @FindBy(xpath = "//img[@alt='Create Account...']")
	private WebElement createAccountBT;
	
}
