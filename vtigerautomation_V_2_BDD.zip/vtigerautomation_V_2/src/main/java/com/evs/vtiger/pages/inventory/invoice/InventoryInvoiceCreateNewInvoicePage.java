package com.evs.vtiger.pages.inventory.invoice;

import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

public class InventoryInvoiceCreateNewInvoicePage extends InventoryInvoiceCreateNewInvoiceOR{

	////  Page Object Model -  Design Pattern or Architecture of Automation Framework
	
	
	private WebUtil wt;
	
	public InventoryInvoiceCreateNewInvoicePage(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void enterInventoryInvoiceInfo() {
		wt.mySendKeys("Invoice Creation",getSubjectTB());
		wt.mySendKeys("10",getCustomerNoTB());
		wt.click(getContactNameSelectBT());
		
		InventoryInvoiceSelectContactNameWindow selectContact = new InventoryInvoiceSelectContactNameWindow(wt);
		selectContact.switchByURLFromInventoryInvoiceWindowToContactName("http://localhost:8888/index.php?module=Contacts&action=Popup&html=Popup_picker&popuptype=specific&form=EditView");
		selectContact.searchAndSelectContactName("Brown");
		selectContact.switchByURLFromInventoryInvoiceWindowToContactName("http://localhost:8888/index.php?module=Invoice&action=EditView&return_action=DetailView&parenttab=Inventory");
		
		wt.click(getAccountNameSelectBT());

		InventoryInvoiceSelectAccountNameWindow selectAccount = new InventoryInvoiceSelectAccountNameWindow(wt);
		selectAccount.switchInventoryInvoiceWindowToAccountNameSelectByURL("http://localhost:8888/index.php?module=Accounts&action=Popup&popuptype=specific_account_address&form=TasksEditView&form_submit=false&fromlink=");
		selectAccount.searchAndSelectAccountName("EDFG Group Limited");
		selectAccount.switchInventoryInvoiceWindowToAccountNameSelectByURL("http://localhost:8888/index.php?module=Invoice&action=EditView&return_action=DetailView&parenttab=Inventory");
		
		wt.mySendKeys("123 Anywhere Street",getBillingAddressTB());
		wt.mySendKeys("Varanshi",getBillingCityTB());
		wt.mySendKeys("Utter Pradesh",getBillingStateTB());
		wt.mySendKeys("24356",getBillingPostalCodeTB());
		wt.mySendKeys("India",getBillingCountryTB());
		wt.click(getCopyBillingAddressBT());
		wt.click(getSearchProductIcon());
		InventoryInvoiceSelectProductWindow inventoryWindow = new InventoryInvoiceSelectProductWindow(wt);
		inventoryWindow.switchInventoryInvoiceWindowToProductSearchByURL("http://localhost:8888/index.php?module=Products&action=Popup&html=Popup_picker&select=enable&form=HelpDeskEditView&popuptype=inventory_prod&curr_row=1&return_module=Invoice&currencyid=1");
		inventoryWindow.searchAndSelectProduct();
		inventoryWindow.switchInventoryInvoiceWindowToProductSearchByURL("http://localhost:8888/index.php?module=Invoice&action=EditView&return_action=DetailView&parenttab=Inventory");
		wt.mySendKeys("This Comment Only For Testing Purpose",getCommentTB());
		wt.mySendKeys("12",getQuentityTB());
	
	
	}
	
	public void clickOnSaveButton() {
		wt.click(getSaveInvoiceBT());
	}
	
	public void clickOnCancelButton() {
		wt.click(getCancelInvoiceBT());

	}
}
