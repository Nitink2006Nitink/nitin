package com.evs.vtiger.pages.inventory.invoice;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class InventoryInvoiceSelectProductWindowOR {

	public InventoryInvoiceSelectProductWindowOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}
	
	@FindBy(xpath = "//input[@value='57']")
	private WebElement productBT;
	
	@FindBy(xpath = "//input[@value='Select Products']")
	private WebElement selectProductBT;
}
