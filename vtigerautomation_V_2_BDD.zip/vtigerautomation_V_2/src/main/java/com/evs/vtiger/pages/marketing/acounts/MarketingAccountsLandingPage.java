package com.evs.vtiger.pages.marketing.acounts;


import com.evs.vtiger.utils.WebUtil;

public class MarketingAccountsLandingPage extends MarketingAccountLandingOR {

	///  code 
	//// Whatever functionality on the page 
	////  we will create method for that
	
	private WebUtil wt;
	
	public MarketingAccountsLandingPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
		
	}

	public void clickCreateMarketingAccountButton() {
    	wt.click(getCreateAccountBT());
    }
	
	public void searchAccount() {
		///  3 line
	}
	
}
