package com.evs.vtiger.pages.marketing.contacts;

import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

public class MarketingContactsCreateNewContactPage extends MarketingContactCreateNewContactOR{
	
	private WebUtil wt;
	
	public MarketingContactsCreateNewContactPage(WebUtil wu) {
		super(wu);
		this.wt = wu;
	}

	public void enterMarketingContactsInfo() {
		
		wt.mySendKeys("Arjun",getFirstNameTB());
		wt.mySendKeys("Yadav",getLastNameTB());
		
		wt.click(getSelectAccountNameBT());
		
		MarketingContactSelectAccountNameWindow accountNameWindow =	PageFactory.initElements(wt.getDriver(), MarketingContactSelectAccountNameWindow.class);
		accountNameWindow.switchByURLFromMarketingContactWindowToAccountName("http://localhost:8888/index.php?module=Accounts&action=Popup&popuptype=specific_contact_account_address&form=TasksEditView&form_submit=false&fromlink=&recordid=");
		accountNameWindow.searchAndSelectAccountName("samplevtiger");
		accountNameWindow.switchByURLFromMarketingContactWindowToAccountName("http://localhost:8888/index.php?module=Contacts&action=EditView&return_action=DetailView&parenttab=Marketing");
		
		wt.selectByValue(getLeadSourceDropDown() , "Self Generated");
		wt.mySendKeys("arjun_yadav123@1secmail.com",getEmailTB());
		wt.mySendKeys("Testing Purpose",getTitleTB());
		wt.mySendKeys("xyz",getMailingStreetTB());
		wt.mySendKeys("Delhi",getMailingCityTB());
		wt.mySendKeys("Utter Predesh",getMailingStateTB());
		wt.mySendKeys("India",getMailingCountryTB());
		wt.click(getAccountInfoCopyTB());
		wt.mySendKeys("This Account Creation is only for testing Purpose",getDescriptionTB());		
	}
	
	public void clickOnSaveButton() {
		wt.click(getSaveMarketingContactBT());

	}
	
	public void clickOnCancelButton() {
		wt.click(getCancelMarketingContactBT());

	}
}
