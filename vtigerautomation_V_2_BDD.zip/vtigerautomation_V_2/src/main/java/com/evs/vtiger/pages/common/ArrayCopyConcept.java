package com.evs.vtiger.pages.common;

import java.util.Arrays;
import java.util.HashMap;

public class ArrayCopyConcept {

	public static void main(String[] args) {
HashMap hs =new HashMap();
hs.put(1, "A");
hs.put(2, "B");
hs.put(3, "C");
hs.put(4, "D");
hs.put(5, "E");

System.out.println(hs.keySet());
System.out.println(hs.values());
	}

}
