package com.evs.vtiger.pages.marketing.leads;

public class MarketingLeadsDetailPage {

}
