package com.evs.vtiger.pages.sales.leads;

import com.evs.vtiger.utils.WebUtil;

public class SalesLeadsLandingPage extends SalesLeadsLandingOR{

	private WebUtil wt;
	
	public SalesLeadsLandingPage(WebUtil wu) {
		super(wu);
		this.wt=wu;
	}

	public void clickOnCreateNewLeadButton() {
		wt.click(getCreateLeadsBT());
	}
}
