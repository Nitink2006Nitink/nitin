package com.evs.vtiger.pages.sales.accounts;

import com.evs.vtiger.utils.WebUtil;

public class SalesAccountsLandingPage extends SalesAccountsLandingOR{

	private WebUtil we;
	
	public SalesAccountsLandingPage(WebUtil wu) {
		super(wu);
		this.we=wu;
	}

	public void clickOnCreateNewAccountButton() {
		we.click(getCreateAccountBT());
	}
}
