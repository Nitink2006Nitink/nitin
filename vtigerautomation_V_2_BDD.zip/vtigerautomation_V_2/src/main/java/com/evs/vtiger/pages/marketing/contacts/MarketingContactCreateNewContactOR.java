package com.evs.vtiger.pages.marketing.contacts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.evs.vtiger.utils.WebUtil;

import lombok.Getter;

@Getter
public class MarketingContactCreateNewContactOR {

	public MarketingContactCreateNewContactOR(WebUtil wu) {
		PageFactory.initElements(wu.getDriver(), this);
	}

	@FindBy(xpath = "//input[@name='firstname']")
	private WebElement firstNameTB;
	
	@FindBy(xpath = "//input[@name='lastname']")
	private WebElement lastNameTB;
	
	@FindBy(xpath = "//td[@class='dvtCellInfo']//input[@name='account_name']//following-sibling::img")
	private WebElement selectAccountNameBT;
	
	@FindBy(xpath = "//select[@name='leadsource']")
	private WebElement leadSourceDropDown;
	
	@FindBy(xpath = "//input[@id='email']")
	private WebElement emailTB;
	
	@FindBy(xpath = "//input[@id='title']")
	private WebElement titleTB;
	
	@FindBy(xpath = "//textarea[@name='mailingstreet']")
	private WebElement mailingStreetTB;
	
	@FindBy(xpath = "//input[@name='mailingcity']")
	private WebElement mailingCityTB;
	
	@FindBy(xpath = "//input[@name='mailingstate']")
	private WebElement mailingStateTB;
	
	@FindBy(xpath = "//input[@name='mailingcountry']")
	private WebElement mailingCountryTB;
	
	@FindBy(xpath = "//b[text()='Copy Mailing Address']//preceding-sibling::input")
	private WebElement accountInfoCopyTB;
	
	@FindBy(xpath = "//textarea[@name='description']")
	private WebElement descriptionTB;
	
	@FindBy(xpath = "(//input[@title='Save [Alt+S]'])[2]")
	private WebElement saveMarketingContactBT;
	
	@FindBy(xpath = "(//input[@title='Cancel [Alt+X]'])[2]")
	private WebElement cancelMarketingContactBT;
	
}
