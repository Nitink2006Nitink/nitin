package com.evs.vtiger.stepdefs.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class HooksVerify {

	@Given("^Navigate To Marketing Account$")
	public void givenStep() {
		
	DateFormat df=	new SimpleDateFormat("dd:MMM:yyyy hh:mm:ss.SSS a");
	String date=df.format(new Date());
	
//	System.out.println(date);
//	
//		try {
//			int a=2/0;	
//		}catch(Exception e) {
//			
//		}
		int x=10;
//		if(x==15) {
//			System.out.println("passed");
//		}else {
//			System.out.println("failed");
//		}
		try {
			Assert.assertEquals("verifying producct count",15, x);
			
		}catch(Throwable e) {
			
		}
		System.out.println(" Go To Marketing Account Page ");
	}
	
	@When("^create account$")
	public void whenStep() {
		System.out.println(" Creating New Account ");
	}

	
	@When("^create contact$")
	public void contactStep() {
		System.out.println(" Creating New Contact ");
	}
	
}
