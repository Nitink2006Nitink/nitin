package com.evs.vtiger.stepdefs.marketing;

import java.util.List;
import java.util.Map;

import com.evs.vtiger.pages.common.CommonPage;
import com.evs.vtiger.pages.marketing.acounts.MarketingAccountsCreateNewAccountPage;
import com.evs.vtiger.pages.marketing.acounts.MarketingAccountsLandingPage;
import com.evs.vtiger.pages.sales.leads.SalesLeadsCreateNewLeadPage;
import com.evs.vtiger.pages.sales.leads.SalesLeadsLandingPage;
import com.evs.vtiger.stepdefs.common.CommonStepDefs;
import com.evs.vtiger.utils.WebUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MarketingStepDefs  {


	private WebUtil webUtil=WebUtil.getInstance();

	@When("^user navigate to Marketing Account$")
	public void gotoMarketingAccount() {
		CommonPage commonPage=new CommonPage(webUtil);
		commonPage.gotoMarketingAccountsPage();

	}



	@And("^click on create Marketing Account button$")
	public void clickCreateAccountButton() {
		MarketingAccountsLandingPage malp=new MarketingAccountsLandingPage(webUtil);
		malp.clickCreateMarketingAccountButton();

	}

	//	@When("^user enter valid account information$")
	//	public void enterMarketingAccountInfo(DataTable dt) {
	//		MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(webUtil);
	//		List<List<String>> listOfDataList=dt.asLists();
	//		for(int i=0; i<=listOfDataList.size()-1;i++) {
	//			List<String> dataList=listOfDataList.get(i);
	//			macap.enterMarketingAccountInfo(dataList);
	//			macap.clickSaveButton();
	//			MarketingAccountsLandingPage malp=new MarketingAccountsLandingPage(webUtil);
	//			malp.clickCreateMarketingAccountButton();
	//
	//		}
	//		
	//		
	//	}

//		@When("^user enter valid account information$$")
//		public void enterMarketingAccountInfo(DataTable dt) {
//			MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(webUtil);
//			List<Map<String, String>> listOfDataMap=dt.asMaps();
//			for(int i=0; i<=listOfDataMap.size()-1;i++) {
//				Map<String, String> dataMap=listOfDataMap.get(i);
//				macap.enterMarketingAccountInfo(dataMap);
//				macap.clickSaveButton();
//				MarketingAccountsLandingPage malp=new MarketingAccountsLandingPage(webUtil);
//				malp.clickCreateMarketingAccountButton();
//	
//			}
//			
//			
//		}

	@When("^user enter valid account information like AccountName as \"([^\"]*)\", Email as \"([^\"]*)\", City as \"([^\"]*)\", Website as \"([^\"]*)\", State as \"([^\"]*)\", pincode as \"([^\"]*)\", Phone as \"([^\"]*)\"$")
	public void enterMarketingAccountInfo(String accountName, String email, String city, String website, String state, String pincode, String phone) {
		MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(webUtil);

		macap.enterMarketingAccountInfo(accountName,  email,  city,  website,  state,  pincode,  phone);

	}

	@And("click on save Account button")
	public void clickSave() {
		MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(WebUtil.getInstance());
		macap.clickSaveButton();
	}


	//	@When("^user enter invalid account information like duplicate accountname as (.*), firstname, lastname etc$")
	//	public void enterInvalidMarketingAccountInfo(String accName) {
	//		MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(webUtil);
	//		macap.enterMarketingAccountInfo(accName);
	//	}
	//	

	@And("^close the browser$")
	public void closeBrowser() {
		CommonPage commonPage = new CommonPage(WebUtil.getInstance());
		commonPage.close();
	}


	@Then("^verify alert massage should be displayed as (.*)$")
	public void verifyAlertMassage(String alertMassage) {
		MarketingAccountsCreateNewAccountPage macap=new MarketingAccountsCreateNewAccountPage(webUtil);
		String massage = macap.verifyAlertMassage(alertMassage);
		System.out.println("Alert Massage is "+massage);

	}

}
