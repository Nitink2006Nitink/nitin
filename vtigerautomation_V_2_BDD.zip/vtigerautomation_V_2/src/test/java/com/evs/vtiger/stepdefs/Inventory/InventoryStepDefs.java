package com.evs.vtiger.stepdefs.Inventory;

import com.evs.vtiger.pages.inventory.invoice.InventoryInvoiceCreateNewInvoicePage;
import com.evs.vtiger.pages.inventory.invoice.InventoryInvoiceLandingPage;
import com.evs.vtiger.pages.sales.leads.SalesLeadsCreateNewLeadPage;
import com.evs.vtiger.utils.WebUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class InventoryStepDefs {

	private  WebUtil webutil=WebUtil.getInstance();
	@And("^Click on create invoice button$")
	public void clickCreateInvoiceButton() {
		InventoryInvoiceLandingPage malp=new InventoryInvoiceLandingPage(webutil);
		malp.clickCreateInventoryInvoiceButton();
		
	}
	
	@When("^user enter valid information like subjectName, accountName, addressDetail, iteamName etc$")
	public void enterInventoryInvoiceInfo() {
		InventoryInvoiceCreateNewInvoicePage macap=new InventoryInvoiceCreateNewInvoicePage(webutil);
		macap.enterInventoryInvoiceInfo();
	}
	

	
}
