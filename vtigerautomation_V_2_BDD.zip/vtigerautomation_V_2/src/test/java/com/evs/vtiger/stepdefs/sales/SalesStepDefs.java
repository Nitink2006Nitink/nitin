package com.evs.vtiger.stepdefs.sales;

import java.util.List;

import com.evs.vtiger.pages.common.CommonPage;
import com.evs.vtiger.pages.sales.leads.SalesLeadsCreateNewLeadPage;
import com.evs.vtiger.pages.sales.leads.SalesLeadsLandingPage;
import com.evs.vtiger.utils.WebUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class SalesStepDefs {

	private WebUtil webUtil=WebUtil.getInstance();
	
	@When("^user navigate to Sales Leads$")
	public void gotoSalesLeads() {
		CommonPage commonPage=new CommonPage(webUtil);
		commonPage.gotoSalesLeadsPage();
		
	}
	
	@And("^click on create Sales Lead button$")
	public void clickCreateSalesLeadsButton() {
	SalesLeadsLandingPage sllp = new SalesLeadsLandingPage(webUtil);
	sllp.clickOnCreateNewLeadButton();
	}
	
	

	@When("^user enter valid account informations$")
	public void enterSalesLeadsInfo(DataTable dt) {
	SalesLeadsCreateNewLeadPage slcl =	new SalesLeadsCreateNewLeadPage(webUtil);
	List<List<String>> listOfDataList = dt.asLists();
	for (int i = 0 ; i < listOfDataList.size() ; i++) {
		List<String> dataList = listOfDataList.get(i);
		slcl.enterSalesLeadsInfo(dataList);
		
	}
	}
	
	@When("^user enter valid account informations like firstName as \\\"([^\\\"]*)\\\", lastName as \\\"([^\\\"]*)\\\", Company as \\\"([^\\\"]*)\\\", leadStatus as \\\"([^\\\"]*)\\\", phone as \\\"([^\\\"]*)\\\", email as \\\"([^\\\"]*)\\\", address as \\\"([^\\\"]*)\\\", city as \\\"([^\\\"]*)\\\", country as \\\"([^\\\"]*)\\\", state as \\\"([^\\\"]*)\\\", descripton as \\\"([^\\\"]*)\\\"$")
	public void enterSalesLeadsInfo(String firstName, String lastName, String Company, String leadStatus, String phone, String email, String address, String city, String country, String state, String description ) {
	
		SalesLeadsCreateNewLeadPage slcl =	new SalesLeadsCreateNewLeadPage(webUtil);
	
		slcl.enterSalesLeadsInfo(firstName, lastName, Company, leadStatus, phone, email, address, city, country, state, description);
		
	}

	
	@And("^click on save Lead button$")
	public void clickLeadSave() {
		SalesLeadsCreateNewLeadPage slcl =	new SalesLeadsCreateNewLeadPage(webUtil);
		slcl.clickOnSaveButton();
		
	}
		
	
}
