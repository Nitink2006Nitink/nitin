package com.evs.vtiger.stepdefs.common;

import com.evs.vtiger.pages.common.CommonPage;
import com.evs.vtiger.utils.WebUtil;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CommonStepDefs {

	private WebUtil webUtil=WebUtil.getInstance();
	
//	@Given("^user is logged in application username as \"([^\"]*)\" , password as \"([^\"]*)\"$")
//	public void launchBrowserAndLogin(String username, String password) {
//		
//		webUtil.launchBrowser();
//		
//		webUtil.openUrl("http://localhost:8888/");
//		CommonPage commonPage=new CommonPage(webUtil);
//		commonPage.validLogin(username, password);
//		
//	}

	@When("^user navigate to inventory invoice$")
	public void gotonventoryInvoce() {
		CommonPage commonPage=new CommonPage(webUtil);
		commonPage.gotoInventoryInvoicePage();
		
	}
	
	
	
}
