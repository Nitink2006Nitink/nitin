package com.evs.vtiger.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\features", 
                  glue="com.evs.vtiger.stepdefs",
                  tags = "@Login or Marketing",
//                  tags = "@Login and @Smoke",
//                  plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json" }
                  plugin = { "pretty", "html:target/cucumber-reports.html" }
                    	
				)

public class Runner {

}

/*  
 * This way is use in previous version
 * tags = {"@Smoke", "@Regression"}
 * tags = {"@Smoke, @Regression"}
 * tags = {"~@Smoke"} 
 * 
 * In New version ---
 *  tags = "@Login and @Smoke",
 *  tags = "@Login or @Smoke",
 *  tags = "not @Smoke",
 *  tags = "@Login and @Smoke and "Sanity",
 *  tags = "@Login or @Smoke or "Sanity",
 *   tags = "@Login and @Smoke" or "Sanity",

	 */