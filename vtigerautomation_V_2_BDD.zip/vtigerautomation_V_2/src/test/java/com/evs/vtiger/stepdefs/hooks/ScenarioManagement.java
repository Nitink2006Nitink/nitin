package com.evs.vtiger.stepdefs.hooks;

import com.evs.vtiger.pages.common.CommonPage;
import com.evs.vtiger.utils.WebUtil;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;

public class ScenarioManagement {
	private WebUtil webUtil=WebUtil.getInstance();
	///  Skip
	
	@Before
	public void beforeScenario() {
      webUtil.launchBrowser();
		webUtil.openUrl("http://localhost:8888/");
		CommonPage commonPage=new CommonPage(webUtil);
		commonPage.validLogin("admin", "Arjun");
	}
	
	@After
	public void afterScenario() {
		CommonPage commonPage=new CommonPage(webUtil);
		commonPage.logout();
		webUtil.close();
	}
	
//	@BeforeStep()
//	public void beforeStep() {
//		System.out.println("Before Step code executed");
//	}
//	
//	@AfterStep()
//	public void afterStep() {
//		System.out.println("After Step code executed");
//	}
//	
//	@Before(order = 2)
//	public void aeforeScenario2() {
//		System.out.println("Before Scenario2 code executed");
//	}
//	@Before(order = 3, value = "@Smoke and @Regression")
//	public void beforeScenario3() {
//		System.out.println("Before Scenario3 code executed");
//
//	}
//	
//	@After(order=2)
//	public void afterScenario2() {
//		System.out.println("after Scenario2 code executed");
//	}
//	
//	@After(order=3)
//	public void afterScenario3() {
//		System.out.println("after Scenario3 code executed");
//
//
//	}	
//	
	
	
	
	
//	@After(order=1)
//	public void AfterScenario2() {
//		System.out.println(" after2 Order 2 Run......");
//	}
//	
//	@After(order=2)
//	public void afterScenario1() {
//		System.out.println(" after1 Order 1 Run......");
//	}
//	
//	@Before(order=1)
//	public void beforeScenario1() {
//		System.out.println(" befoure1 Order 1 Run......");
//	}
//	
//	@Before(order=2)
//	public void BeforeScenario2() {
//		
//		System.out.println(" befoure2 Order 2 Run......");
//	}
	

}
